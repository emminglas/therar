*⭐ Please star this repo if it was useful to you ⭐*
# zKitap2Pdf
zKitap2Pdf is an app that turns your shitty e-textbook apps (Fernus Z-Kitap etc.) to PDF's.
it works by continiously taking screenshots of the books pages and merging them in a PDF file.
unlike its competitor (ZKitapToPDF by BBBaysal), you dont need to enter coordinates manually, you just need to click where you want to place your markers, simple as that.

![zKitap2PDF](https://github.com/Ucaninek/zKitap2Pdf/assets/43094930/00764a13-2614-47af-9a6a-0ddd92c88e36)

## How to use?
1) Open your E-Textbook app and go to page you want to start from.
2) Click on Pick All
3) Click at 3 points, first the top left corner of the page, then the bottom right corner, and lastly, the next page button. *(you can also double click each XY box to pick the points individually.)*
4) Select how many pages you want to capture (starting from current page)
5) Click on Start wait for it to finish 💤
6) Your PDF will be dropped at `./PDFs/xxx.pdf`, you can click Open PDF to open it.
7) Enjoy!!! ❤️
