﻿using System;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Threading;
using Microsoft.Win32;

namespace Furkola
{
    internal class Program
    {
        static void Main()
        {
            PrintGradientTitle();
            PrintSeparatorLine();
            WriteWithTimestamp("Spooflamak istiyor musunuz?");
            WriteWithTimestamp("1: Evet");
            WriteWithTimestamp("2: Hayır");
            WriteWithTimestamp("Bir seçenek girin: ");
            string choice = Console.ReadLine();

            if (choice == "1")
            {
                HWID_Spoofer();
            }
            else if (choice == "2")
            {
                WriteWithTimestamp("Ne aciyon o zaman amk");
                Thread.Sleep(500);
                Environment.Exit(0);
            }
            else
            {
                WriteWithTimestamp("Geçersiz seçim.");
                Thread.Sleep(500);
                Environment.Exit(0);
            }
        }

        private static void HWID_Spoofer()
        {
            if (!IsAdministrator())
            {
                WriteWithTimestamp("Uygulamayı yönetici olarak çalıştırmalısınız.");
                return;
            }

            UpdateProcessorNameStrings();
            WriteWithTimestamp("HWID Spoofer işlemi tamamlandı.");
            WriteWithTimestamp("Spoof tamamlandı!");
        }

        private static bool IsAdministrator()
        {
            WindowsIdentity current = WindowsIdentity.GetCurrent();
            WindowsPrincipal windowsPrincipal = new WindowsPrincipal(current);
            return windowsPrincipal.IsInRole(WindowsBuiltInRole.Administrator);
        }

        private static void UpdateProcessorNameStrings()
        {
            string str = "HARDWARE\\DESCRIPTION\\System\\CentralProcessor";
            for (int i = 0; i < 4; i++)
            {
                using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(str + "\\" + i.ToString(), true))
                {
                    bool flag = registryKey != null;
                    if (flag)
                    {
                        Random random = new Random();
                        registryKey.SetValue("ProcessorNameString", random.Next(100000, 999999).ToString(), RegistryValueKind.String);
                    }
                }
            }
        }

        private static void PrintGradientTitle()
        {
            string[] lines = new string[]
            {
                "███████╗ ██╗░░░██╗ ██████╗░ ██╗░░██╗ ░█████╗░ ██╗░░░░░ ░█████╗░",
                "██╔════╝ ██║░░░██║ ██╔══██╗ ██║░██╔╝ ██╔══██╗ ██║░░░░░ ██╔══██╗",
                "█████╗░░ ██║░░░██║ ██████╔╝ █████═╝░ ██║░░██║ ██║░░░░░ ███████║",
                "██╔══╝░░ ██║░░░██║ ██╔══██╗ ██╔═██╗░ ██║░░██║ ██║░░░░░ ██╔══██║",
                "██║░░░░░ ╚██████╔╝ ██║░░██║ ██║░╚██╗ ╚█████╔╝ ███████╗ ██║░░██║",
                "╚═╝░░░░░ ░╚═════╝░ ╚═╝░░╚═╝ ╚═╝░░╚═╝ ░╚════╝░ ╚══════╝ ╚═╝░░╚═╝"
            };

            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Magenta;
            int consoleWidth = Console.WindowWidth;
            int textWidth = lines[0].Length;
            int paddingLeft = (consoleWidth - textWidth) / 2;

            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i];
                string paddedLine = line.PadLeft(paddingLeft + line.Length);
                Console.WriteLine(paddedLine);
            }
            Console.ResetColor();
        }

        private static void PrintSeparatorLine()
        {
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine(new string('═', Console.WindowWidth));
            Console.ResetColor();
        }

        private static void WriteWithTimestamp(string text)
        {
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.Write($"[{DateTime.Now:HH:mm:ss}] ");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine(text);
            Console.ResetColor();
        }


        internal static class HookFixer
        {
            public static int Fix(IntPtr handle)
            {
                return 0; 
            }
        }

        internal static class WINAPI
        {
            [DllImport("kernel32.dll", SetLastError = true)]
            public static extern IntPtr VirtualAllocEx(IntPtr hProcess, IntPtr lpAddress, uint dwSize, AllocationType flAllocationType, MemoryProtection flProtect);

            [DllImport("kernel32.dll", SetLastError = true)]
            public static extern bool WriteProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, byte[] lpBuffer, uint nSize, out IntPtr lpNumberOfBytesWritten);

            [DllImport("kernel32.dll", SetLastError = true)]
            public static extern IntPtr CreateRemoteThread(IntPtr hProcess, IntPtr lpThreadAttributes, uint dwStackSize, IntPtr lpStartAddress, IntPtr lpParameter, uint dwCreationFlags, IntPtr lpThreadId);

            [DllImport("kernel32.dll", SetLastError = true)]
            public static extern IntPtr GetProcAddress(IntPtr hModule, string lpProcName);

            [Flags]
            public enum AllocationType : uint
            {
                COMMIT = 0x00001000,
                RESERVE = 0x00002000,
            }

            [Flags]
            public enum MemoryProtection : uint
            {
                PAGE_READWRITE = 0x04
            }
        }
    }
}
